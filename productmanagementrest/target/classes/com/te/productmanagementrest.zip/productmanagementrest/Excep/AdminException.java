package com.te.productmanagementrest.Excep;

public class AdminException extends RuntimeException{

	public AdminException(String msg) {
		super(msg);
	}
}
